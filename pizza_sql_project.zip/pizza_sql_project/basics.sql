-- BASICS 

-- Q1. Retrieve the total number of orders placed.
select count(order_id) as total_orders
from orders;

-- Q2. Calculate the total revenue generated from pizza sales.
select round(sum(p.price*o.quantity),2) as total_revenue
from pizzas as p
join order_details as o
on p.pizza_id = o.pizza_id;

-- Q3. Identify the highest-priced pizza.
select pt.name , p.price
from pizzas as p 
join pizza_types as pt 
on p.pizza_type_id = pt.pizza_type_id
order by p.price desc limit 1;

-- Q4. Identify the most common pizza size ordered.
select size, count(order_details_id) as most_common_pizza
from pizzas as p 
join order_details as od
on p.pizza_id = od.pizza_id
group by size
order by   most_common_pizza desc limit 1  ;

-- Q5.List the top 5 most ordered pizza types along with their quantities. 
select pt.name , sum(quantity)  as quantity
from pizzas as p
join pizza_types as pt 
on p.pizza_type_id = pt.pizza_type_id
join order_details as od 
on  p.pizza_id = od.pizza_id
group by name
order by quantity desc limit 5 ;
