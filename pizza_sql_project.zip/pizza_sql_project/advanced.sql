--  ADVANCED:
-- Q1. Calculate the percentage contribution of each 
--     pizza type to total revenue.

select category , round(sum(price*quantity) /
(select round(sum(p.price*o.quantity),2) 
from pizzas as p
join order_details as o
on p.pizza_id = o.pizza_id)*100,2) as revenue

from pizzas as p 
join pizza_types as pt 
on p.pizza_type_id = pt.pizza_type_id
join order_details as od
on p.pizza_id = od.pizza_id
group by category ;

-- Q2. Analyse the cumulative revenue generated over time 
-- cumulative revenue  is today + yesterday 

select order_date,
sum(revenue) over (order by order_date) as cum_revenue
from
(select order_date, round(sum(price*quantity),2) as revenue
from pizzas as p 
join order_details as od 
on p.pizza_id = od.pizza_id
join orders as o
on o.order_id =od.order_id
group by order_date) as sales;

-- Q3. Determine the top 3 most ordered pizza types 
--     based on revenue for each pizza category.

select name , revenue
from 
(select name, category , revenue , 
rank() over(partition by category order by revenue desc) as rn
from 
(select name , category, round(sum(price*quantity),2) as revenue
from pizzas as p 
join pizza_types as pt
on p.pizza_type_id = pt.pizza_type_id 
join order_details as od
on od.pizza_id = p.pizza_id
group by  name , category) as a) as b
where rn>=3 ;