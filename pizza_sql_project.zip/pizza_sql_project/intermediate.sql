-- INTERMEDIATE 
 
-- Q1. Join the necessary tables to find the total quantity of
--     each pizza category ordered.
select category , sum(quantity) as  quantity
from pizzas  as  p 
join pizza_types as pt 
on p.pizza_type_id  = pt.pizza_type_id 
join order_details as od  
on p.pizza_id = od.pizza_id 
group by category
order by quantity;

-- Q2. Determine the distribution of orders by hour of the day.
select hour(order_time) as hour , count(order_id) as order_count
from orders
group by hour(order_time) ;

-- Q3. Join relevant tables to find the category-wise distribution of pizzas.
select category , count(name)
from pizza_types
group by category;


-- Q4. Group the orders by date and calculate the average number
--     of pizzas ordered per day.
select round(avg(daily_order),2)  as avg_pizza_order_per_day
from   
( select order_date , sum(quantity) as daily_order
from  orders as o 
join order_details as od 
on o.order_id = od.order_id
group by order_date) as order_quantity;

-- Q5. Determine the top 3 most ordered pizza types based on revenue.
select pt.pizza_type_id , sum(p.price*od.quantity) as revenue
from  pizzas as p  
join order_details as od 
on p.pizza_id = od.pizza_id
join pizza_types as pt 
on pt.pizza_type_id = p.pizza_type_id
group by pizza_type_id
order by revenue desc limit 3;

